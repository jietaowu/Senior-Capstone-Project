<?php 


$conn = new PDO("mysql:host=localhost;dbname=ou_ecommerce", "root", "root");


 ?>